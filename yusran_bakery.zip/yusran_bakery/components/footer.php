  <footer class="bg-gradient-to-r from-brown to-brownDark text-white py-5 text-center">
    <p>© 2025 Yusran Bakery. All Rights Reserved.</p>
    <p class="text-sm opacity-90">Alamat: Jl. Ahmad Yani No. 12, Bandar Lampung • WhatsApp: 0878-9459-0492</p>
  </footer>