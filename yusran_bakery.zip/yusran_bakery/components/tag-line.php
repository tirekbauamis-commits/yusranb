  <section class="max-w-5xl mx-auto bg-white rounded-2xl shadow-md p-8 mt-10 mb-16">
    <h2 class="text-2xl font-semibold text-brownDark mb-4">Kenapa Yusran Bakery?</h2>
    <p class="mb-3">Kami menggunakan bahan pilihan dan resep turun-temurun untuk menghasilkan roti dan donat terbaik di Bandar Lampung.</p>
    <p class="text-gray-600">Setiap gigitan adalah rasa bahagia.</p>
  </section>